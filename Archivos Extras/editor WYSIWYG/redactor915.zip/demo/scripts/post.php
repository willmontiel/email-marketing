<?php
echo stripslashes($_POST['content']);
?>